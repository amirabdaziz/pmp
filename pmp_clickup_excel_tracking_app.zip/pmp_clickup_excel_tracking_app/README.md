# FAZ-CorrS PMO Tracker

This application was generated from the Excel file: `Copy of FAZ-CorrS Progress Update (003).xlsx`.

## How to test locally
Open `index.html` in a browser.

## GitHub Pages
Upload all files in this folder to your `pmp` repository root. Your URL should be:

https://amirabdaziz.github.io/pmp/

## Demo login
- admin / Admin@123
- amir / Amir@123
- mustaza / Mustaza@123
- najwa / Najwa@123
- aimar / Aimar@123
- management / Mgmt@123

## Data source
All tasks are generated from `data/excel-tracker-data.json`, which was parsed from your Excel tracker.

Summary:
- Total tasks: 78
- Overall progress: 45%
- Phases: 5
